package com.local.salesorder.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.local.salesorder.model.SalesOrder;
import com.local.salesorder.service.SalesOrderService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * This is the controller class for calling different requests. It checks the
 * URL mapping and do the corresponding action
 * 
 * @author Sajana
 * @version 1.0
 * @since 25 Apr 2020
 */
@RestController
@Api(value = "API Description") // it description of api at top
@RequestMapping("/salesorder")
public class SalesOrderController {
	@Autowired
	private SalesOrderService service;

	/**
	 * This method is used to find all Sales Order details
	 * 
	 * @return list of SalesOrder as List<SalesOrder>
	 */
	@ApiOperation(value = "It will return list of SalesOrder")        // it description of api
	@GetMapping("")
	// it will cache result and key name will be "orders"
	@Cacheable(value="orders")
	public List<SalesOrder> getAllSalesOrders() {
		System.out.println("getSalesOrders");
		return service.findAllSalesOrders();
	}

	/**
	 * This method is used to find the Sales Order details by id
	 * 
	 * @param orderId
	 * @return Sales Order
	 */
	 @ApiOperation(value = "It will return SalesOrder by orderId")                // it description of api
	@GetMapping("/{orderId}")
	@Cacheable(value="orders")
	public SalesOrder getSalesOrderById(@PathVariable("orderId") int orderId) {
		return service.findSalesOrderById(orderId);
	}

	/**
	 * This method is used to create the SalesOrder details
	 * 
	 * @param salesOrder as SalesOrder
	 */
	 @ApiOperation(value = "It will add new SalesOrder")               // it description of api
	@PostMapping("")
	// It will clear cache when new SalesOrder save to database
	@CacheEvict(value = "orders",allEntries = true)
	public SalesOrder createSalesOrder(@RequestBody SalesOrder salesOrder) {
		return service.saveSalesOrder(salesOrder);
	}

	/**
	 * This method is used to update the SalesOrder details by using id
	 * 
	 * @param orderId
	 * @param salesorder as SalesOrder
	 */
	 @ApiOperation(value = "It will update SalesOrder")                // it description of api
	@PutMapping("/{orderId}")
	// It will clear cache when update any SalesOrder to database
	@CacheEvict(value = "orders",key="#orderId")
	public SalesOrder updateSalesOrder(@PathVariable("orderId") int orderId, @RequestBody SalesOrder salesorder) {
		salesorder.setOrderId(orderId);
		return service.saveSalesOrder(salesorder);
	}

	/**
	 * This method is used to remove the SalesOrder by using orderId
	 * 
	 * @param orderId
	 */
	 @ApiOperation(value = "It will delete SalesOrder")                // it description of api
	@DeleteMapping("/{orderId}")
	// It will clear cache when delete any SalesOrder to database
	@CacheEvict(value = "orders",key="#orderId")
	public void removeSalesOrder(@PathVariable("orderId") int orderId) {
		service.deleteSalesOrderById(orderId);
	}

}
