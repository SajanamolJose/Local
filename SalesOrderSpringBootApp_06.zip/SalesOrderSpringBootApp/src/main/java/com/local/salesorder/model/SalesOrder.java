package com.local.salesorder.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * This is the model class for SalesOrder table
 * 
 * @author Sajana
 * @version 1.0
 * @since 25 Apr 2020
 */
@Entity
public class SalesOrder {
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	public int orderId;
	private String orderDes;
	private int orderQunt;
	private int orderAmnt;

	// Constructors
	public SalesOrder() {
		super();
	}

	public SalesOrder(int orderId, String orderDes, int orderQunt, int orderAmnt) {
		super();
		this.orderId = orderId;
		this.orderDes = orderDes;
		this.orderQunt = orderQunt;
		this.orderAmnt = orderAmnt;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getOrderDes() {
		return orderDes;
	}

	public void setOrderDes(String orderDes) {
		this.orderDes = orderDes;
	}

	public int getOrderQunt() {
		return orderQunt;
	}

	public void setOrderQunt(int orderQunt) {
		this.orderQunt = orderQunt;
	}

	public int getOrderAmnt() {
		return orderAmnt;
	}

	public void setOrderAmnt(int orderAmnt) {
		this.orderAmnt = orderAmnt;
	}

}
