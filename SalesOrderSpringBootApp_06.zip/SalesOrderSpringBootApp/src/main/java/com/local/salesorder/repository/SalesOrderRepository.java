package com.local.salesorder.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.local.salesorder.model.SalesOrder;

/**
 * 
 * 
 * @author Sajana
 * @version 1.0
 * @since 25 Apr 2020
 */
@Repository
public interface SalesOrderRepository extends CrudRepository<SalesOrder, Integer> {

}