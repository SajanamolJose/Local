package com.local.salesorder.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.local.salesorder.model.SalesOrder;
import com.local.salesorder.repository.SalesOrderRepository;

/**
 * 
 * 
 * @author Sajana
 * @version 1.0
 * @since 25 Apr 2020
 */

@Service
public class SalesOrderService {
	@Autowired
	private SalesOrderRepository repository;

	// Find all Sales Orders
	public List<SalesOrder> findAllSalesOrders() {
		List<SalesOrder> salesorders = new ArrayList<SalesOrder>();
		repository.findAll().forEach(salesorder ->salesorders.add(salesorder) );
		return salesorders;
	}

	// Find Sales Order By orderId
	public SalesOrder findSalesOrderById(int orderId) {
		return repository.findById(orderId).get();

	}

	// Save Sales Order
	public SalesOrder saveSalesOrder(SalesOrder salesOrder) {
		return repository.save(salesOrder);
	}

	// Delete Sales Order
	public void deleteSalesOrderById(int orderId) {
		repository.deleteById(orderId);
	}

}
