insert into SALES_ORDER values(1,10000,'iphone',1);
insert into SALES_ORDER values(2,12000,'Samsung J26',1);
insert into SALES_ORDER values(3,20000,'LED TV',1);
insert into SALES_ORDER values(4,13000,'MI 7PRO',1);
insert into SALES_ORDER values(5,15000,'XXX',1);