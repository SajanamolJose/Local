package com.local.salesorder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.local.salesorder.model.SalesOrder;
import com.local.salesorder.repository.SalesOrderRepository;
import com.local.salesorder.service.SalesOrderService;
@ExtendWith(SpringExtension.class)
@SpringBootTest
class SalesOrderSpringBootAppApplicationTests {
	@Autowired
	private SalesOrderService service;
	@MockBean
	private SalesOrderRepository repository;

	@Test
	public void getAllSalesOrdersTest() {
		when(repository.findAll())
				.thenReturn(Stream.of(new SalesOrder(1, "ABCD", 2, 1000), new SalesOrder(2, "ABCE", 1, 1001))
						.collect(Collectors.toList()));
		assertEquals(2, service.findAllSalesOrders().size());
	}

	@Test
	public void getSalesOrderByIdTest() {
		int ordrId = 1;
		SalesOrder salesOrder = new SalesOrder(1, "iphone", 1, 10000);
		when(repository.findById(ordrId)).thenReturn(Optional.of(salesOrder));
		SalesOrder actualResult = service.findSalesOrderById(ordrId);
		assertEquals(salesOrder, actualResult);
	}

	@Test
	public void saveSalesOrderTest() {
		SalesOrder salesOrder = new SalesOrder(1, "ABCD", 1, 12456);
		when(repository.save(salesOrder)).thenReturn(salesOrder);
		assertEquals(salesOrder, service.saveSalesOrder(salesOrder));
	}

	@Test
	public void updateSalesOrderTest() {
		SalesOrder salesOrder = new SalesOrder(1, "ABCD", 1, 12456);
		when(repository.save(salesOrder)).thenReturn(salesOrder);
		SalesOrder actualResult = service.saveSalesOrder(salesOrder);
		assertEquals(salesOrder, actualResult);
	}

	@Test
	public void deleteSalesOrderTest() {
		int ordrId = 1;
		service.deleteSalesOrderById(ordrId);
		verify(repository, times(1)).deleteById(ordrId);
	}
}
